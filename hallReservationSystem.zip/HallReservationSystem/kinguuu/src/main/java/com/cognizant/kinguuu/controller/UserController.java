package com.cognizant.kinguuu.controller;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.cognizant.kinguuu.bean.UserDetails;

import com.cognizant.kinguuu.repository.UserDetailsRepository;

@RestController
public class UserController {

	
	@Autowired
	private UserDetailsRepository userRepository;

	@RequestMapping("/")
	public String sayHello() {
		return "hello";
	}

	@PutMapping("/userdetails")
	public void putUsers( @RequestBody UserDetails userdetails) {
		
		userRepository.save(userdetails);
	}
}
