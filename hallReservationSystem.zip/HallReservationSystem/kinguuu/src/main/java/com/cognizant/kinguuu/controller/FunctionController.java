package com.cognizant.kinguuu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.kinguuu.bean.Function;
import com.cognizant.kinguuu.service.FunctionService;

@RestController
@RequestMapping("/functionhall")
public class FunctionController {
	@Autowired
	FunctionService functionservice;
	
	@PutMapping()
	public Function bookfunction(@RequestBody Function function) {
		return functionservice.bookFunctionhall(function);
	}

}
