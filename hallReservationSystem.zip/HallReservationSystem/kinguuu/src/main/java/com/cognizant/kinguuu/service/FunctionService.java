package com.cognizant.kinguuu.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.cognizant.kinguuu.bean.Function;
import com.cognizant.kinguuu.repository.FunctionRepository;

@Service
public class FunctionService {
	@Autowired 
	FunctionRepository functionrepository;
	
	public List<Function> getallavailabledates(){
		return functionrepository.findAll();
	}
	
//	public Function getbydates(Date dateofbooking) {
//		Function function= functionrepository.getOne(dateofbooking);
//	}
	
	
	public Function bookFunctionhall( Function function) {
		
	return functionrepository.save(function);
	}
}
