package com.cognizant.kinguuu.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name ="function")
@EntityListeners(AuditingEntityListener.class)
public class Function {
	@Id
	@Column()
	private int id;
	@Column()
	private String firstname;
	@Column()
	private String lastname;
	@Column()
	private String gmail;
	@Column()
	private long contactnumber;
	@Column()
	private Date dateofbooking;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getGmail() {
		return gmail;
	}
	public void setGmail(String gmail) {
		this.gmail = gmail;
	}
	public long getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(long contactnumber) {
		this.contactnumber = contactnumber;
	}
	public Date getDateofbooking() {
		return dateofbooking;
	}
	public void setDateofbooking(Date dateofbooking) {
		this.dateofbooking = dateofbooking;
	}
//	public Function(int id, String firstname, String lastname, String gmail, long contactnumber, Date dateofbooking) {
//		super();
//		this.id = id;
//		this.firstname = firstname;
//		this.lastname = lastname;
//		this.gmail = gmail;
//		this.contactnumber = contactnumber;
//		this.dateofbooking = dateofbooking;
//	}
	@Override
	public String toString() {
		return "Function [id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", gmail=" + gmail
				+ ", contactnumber=" + contactnumber + ", dateofbooking=" + dateofbooking + "]";
	}
	
	
}
