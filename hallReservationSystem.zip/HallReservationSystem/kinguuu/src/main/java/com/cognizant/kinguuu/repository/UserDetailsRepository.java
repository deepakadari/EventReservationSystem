package com.cognizant.kinguuu.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.kinguuu.bean.UserDetails;

public interface UserDetailsRepository extends JpaRepository<UserDetails, String> {

}
