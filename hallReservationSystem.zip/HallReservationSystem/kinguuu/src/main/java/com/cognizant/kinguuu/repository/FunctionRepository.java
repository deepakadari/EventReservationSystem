package com.cognizant.kinguuu.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.kinguuu.bean.Function;

@Repository
public interface FunctionRepository extends JpaRepository<Function, Integer> {
	

}
