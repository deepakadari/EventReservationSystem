package com.cognizant.kinguuu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KinguuuApplication {

	public static void main(String[] args) {
		SpringApplication.run(KinguuuApplication.class, args);
	}

}
